import SwiftUI
import NaturalLanguage

// Sample data: Dictionary where the key is a text, and the value is a list of keywords.
let textData: [String: [String]] = [
    "（2022 全国甲卷第 14 题）14. （6 分）北京 2022 年冬奥会首钢滑雪大跳台局部示意图如图所示。运动员从 a 处由静止自由滑下，到 b 处起跳，c 点为 a、b 之间的最低点，a、c 两处的高度差为 h。要求运动员经过 c 点时对滑雪板的压力不大于自身所受重力的 k 倍，运动过程中将运动员视为质点并忽略所有阻力，则 c 点处这一段圆弧雪道的半径不应小于（ ）": ["机械能守恒定律", "牛顿第二定律", "牛顿第三定律"],
    "（2022 全国甲卷第 15 题）长为 l 的高速列车在平直轨道上正常行驶，速率为 v0，要通过前方一长为 L 的隧道，当列车的任一部分处于隧道内时，列车速率都不允许超过 v(v<v0)。已知列车加速和减速时加速度的大小分别为 a 和 2a，则列车从减速开始至回到正常行驶速率 v0 所用时间至少为（ ）": ["加速度", "速度"]
    
    // Add more texts and their respective keywords here
]

// Function to preprocess text (tokenization)
func preprocessText(_ text: String) -> [String] {
    let tokenizer = NLTokenizer(unit: .word)
    tokenizer.string = text
    
    var tokens: [String] = []
    tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
        let word = String(text[tokenRange]).lowercased()
        tokens.append(word)
        return true
    }
    return tokens
}

// Function to calculate similarity between two texts based on word overlap
func calculateSimilarity(newText: String, existingText: String) -> Float {
    let newTextTokens = preprocessText(newText)
    let existingTextTokens = preprocessText(existingText)
    
    let commonWords = Set(newTextTokens).intersection(Set(existingTextTokens))
    
    // Simple similarity score: ratio of common words to total words
    return Float(commonWords.count) / Float(existingTextTokens.count)
}

// Function to find the closest matching keywords from the stored texts
func findClosestKeywords(for text: String) -> [String] {
    var bestMatchKeywords: [String] = []
    var highestSimilarity: Float = 0.0
    
    for (existingText, keywords) in textData {
        let similarity = calculateSimilarity(newText: text, existingText: existingText)
        
        if similarity > highestSimilarity {
            highestSimilarity = similarity
            bestMatchKeywords = keywords
        }
    }
    
    return bestMatchKeywords
}

// SwiftUI View
struct ContentView: View {
    @State private var inputText: String = ""
    @State private var matchingKeywords: [String] = []
    
    var body: some View {
        VStack {
            TextField("Enter text", text: $inputText)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button("Find Closest Keywords") {
                matchingKeywords = findClosestKeywords(for: inputText)
            }
            .padding()
            
            if !matchingKeywords.isEmpty {
                Text("Closest Keywords:")
                    .font(.headline)
                    .padding(.top)
                
                ForEach(matchingKeywords, id: \.self) { keyword in
                    Text(keyword)
                        .padding(.vertical, 2)
                }
            } else {
                Text("No keywords found yet.")
                    .padding(.top)
            }
        }
        .padding()
    }
}




